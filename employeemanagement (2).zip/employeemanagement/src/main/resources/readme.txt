Employee Management
============================================
Employee Tables:
    Employee - department_id
    Employee_Personal_Details(employee_id)(designation_id)
    Employee_Payroll_Details(employee_id)
    Employee_Passport_Details(employee_id)
    Employee_Address(employee_id)

Department
Designation

==============================================
url for H2 database: http://localhost:8080/h2-console/


=================================================
Url for springboot
https://zetcode.com/springboot/datajpaquery/

===============================================
{
    "hireDate": "2017-07-06",
    "hireManagerId": 5,
    "departmentId": 5,
    "designationId": 3,
    "emailAddress": "hjsfgmail.com",
    "firstName": "Rani",
    "lastName": "Ratna",
    "bankName": "Bank of Navy",
    "bankCode": "GTh37478",
    "passportNumber": "HGGH83257345",
    "validFrom": "1999-07-06",
    "validTo": "2023-07-06",
    "mobileNumber": 9087324554,
    "accountNumber": 43534,
    "addressDTO": {
        "line1": "dsgsgsgs",
        "line2": "sdfdgd",
        "city": "Rajasthan",
        "zipCode": 346663
    }
    }

===============================================
